# MR EARN & CONNECT
### *"Find Opportunities. Connect Skills. Earn."*

**Context:** Malla Reddy Deemed to be University (MRDU), Tirupati  
**Category:** Campus Innovation & Student Opportunity Platform  
**Ideathon Build:** Full Working Multi-Portal Web Application

---

## 💡 Project Vision & Overview

**MR EARN & CONNECT** is a unified student opportunity ecosystem developed for **Malla Reddy Deemed to be University (MRDU), Tirupati**. Instead of students having to search across disjointed job boards, internship portals, freelance sites, and campus notice boards, MR EARN & CONNECT brings the complete student journey into one cohesive, interactive platform:

$$\text{Learn} \rightarrow \text{Build Skills} \rightarrow \text{Create Profile} \rightarrow \text{Analyze Skills} \rightarrow \text{Connect} \rightarrow \text{Find Jobs/Internships} \rightarrow \text{Apply} \rightarrow \text{Offer Services} \rightarrow \text{Earn} \rightarrow \text{Showcase Portfolio} \rightarrow \text{Grow}$$

---

## ⚠️ Critical Architectural Guarantee: NO AI JOB MATCHING

As required by the Ideathon specifications, **MR EARN & CONNECT strictly avoids black-box AI algorithms, opaque vector embeddings, or machine-learning recommendation models for candidate/job selection**.

Instead, the platform features:
### **“Skill Compatibility Analysis”**
- **100% Explainable & Transparent Python Logic**: Evaluates deterministic set intersections between a student's verified skills and recruiter requirements.
- **Visual Breakdown**:
  - **Matched Skills**: Tagged with green checkmarks (`✔ Python`, `✔ SQL`)
  - **Skills to Develop**: Tagged with warning badges (`⚠ Flask`)
  - **Compatibility Percentage**: Transparent formula: $\left(\frac{\text{Matched Required Skills}}{\text{Total Required Skills}}\right) \times 100$
- **Student Empowerment**: The student clearly understands why they match or what specific skill to study before applying.

---

## 👥 Four User Roles & Capabilities

| Role | Description | Key Capabilities |
| :--- | :--- | :--- |
| **👨‍🎓 Student** | Undergraduate student at MRDU | Create profile portfolio, document Technical/Digital/Soft skills with self-reported levels, view **Skill Analysis** (completion score & level visualization), search & apply for jobs/internships with compatibility feedback, list skill-to-earn services, complete orders, receive **Demo Earnings**, connect with peers, and showcase projects & achievements. |
| **🏢 Employer** | Hiring partner & recruiter | Register enterprise profile, post/edit/delete jobs and internships, view student applicant portfolios, examine candidate compatibility scores, and update application review stages (*Applied &rarr; Under Review &rarr; Shortlisted &rarr; Selected / Rejected*). |
| **👤 Customer** | Faculty, students & campus clients | Browse skill marketplace (record writing, handwriting, typing, data entry, PPT preparation, tutoring, coding), submit order requests with instructions, track order progress, and submit 1–5 star ratings with written reviews. |
| **👨‍💼 Admin** | University platform administrator | Manage all users, jobs, internships, services, orders, demo earnings, achievements, and publish/delete campus announcements and opportunity events. |

---

## 🐍 Technology Stack

- **Backend:** Python 3.14
- **Web Framework:** Flask (Lightweight, robust, standard WSGI)
- **Database:** SQLite3 with foreign keys enabled (`PRAGMA foreign_keys = ON;`)
- **Frontend:** Semantic HTML5, Vanilla CSS3 (Custom design system with glassmorphism & responsive grid), Vanilla JavaScript
- **Security:** Werkzeug password hashing (`generate_password_hash`, `check_password_hash`), Session cookies, Role-Based Access Control (RBAC) decorators

---

## 🗄️ Relational Database Schema (SQLite3)

The SQLite database (`database.db`) consists of 16 structured relational tables:

1. `users` — Authentication, roles (`student`, `employer`, `customer`, `admin`), phone, avatars.
2. `student_profiles` — College, department, course, year, education, CGPA, bio, resume link, preferences.
3. `skills` — Categorized skills (`Technical`, `Digital`, `Soft`) with levels (`Beginner`, `Intermediate`, `Advanced`).
4. `companies` — Company profiles, descriptions, websites, and logos.
5. `jobs` — Title, category, description, responsibilities, qualification, skills, salary, location, job type.
6. `internships` — Title, description, skills, eligibility, duration, stipend, location, deadline.
7. `applications` — Job & internship applications with review pipeline status.
8. `services` — Skill-to-Earn marketplace listings (Record Writing, Typing, PPT, Tutoring, etc.) with price & delivery time.
9. `orders` — Customer order requests, requirements, status (*Requested &rarr; Accepted &rarr; In Progress &rarr; Completed &rarr; Rated*), and amounts.
10. `ratings` — 1–5 star customer reviews and written testimonials.
11. `earnings` — Audit records of completed service payouts (Prototype Demo Earnings).
12. `opportunities` — Hackathons, Ideathons, competitions, workshops, and scholarships.
13. `achievements` — Honors, awards, hackathon prizes, and verified certificates.
14. `projects` — Student project showcase with tech stack tags and GitHub links.
15. `announcements` — Official MRDU campus circulars and recruitment notices.
16. `connections` — Peer and mentor networking records.

---

## ⚡ Quick Demo Accounts (1-Click Instant Login Included!)

A **1-Click Instant Demo Login Bar** is available on the Login page (`/login`) for live presentations:

| Role | Email | Password | Persona / Details |
| :--- | :--- | :--- | :--- |
| **👨‍🎓 Student** | `arjun@student.mrdu.edu` | `Student@123` | Arjun Kumar (B.Tech CSE-AIML 1st Year, skills in Python, HTML, SQL, Typing, Record Writing) |
| **🏢 Employer** | `techcorp@company.com` | `Employer@123` | TechCorp Solutions HR (Hiring for Python Developers, Cloud Trainees, Interns) |
| **👤 Customer** | `sharma@faculty.mrdu.edu`| `Customer@123` | Prof. K. Sharma (MRDU Faculty requesting record formatting & Python assistance) |
| **👨‍💼 Admin** | `admin@mrearn.mrdu.edu` | `Admin@123` | MRDU Platform Administrator |

---

## 🎬 17-Step Winning Ideathon Demo Walkthrough

Follow this exact story to demonstrate the complete application live to judges:

1. **Step 1 — Register:** Click **Register**, create an account for *Arjun Kumar* (or click the 1-click demo button).
2. **Step 2 — Build Profile:** Open **My Profile** &rarr; **Edit Portfolio**. Enter *B.Tech CSE-AIML*, *1st Year*, CGPA `9.1`, bio, and resume link.
3. **Step 3 — Skill Levels:** Open **My Skills**. View self-reported skills:
   - Python &mdash; *Advanced (90%)*
   - HTML &mdash; *Intermediate (70%)*
   - SQL &mdash; *Intermediate (70%)*
   - Typing &mdash; *Advanced (90%)*
   - Record Writing &mdash; *Advanced (90%)*
4. **Step 4 — Profile Analysis:** Open **My Skills Analysis**. Observe the transparent completion bar (**85% Complete**), the 7-section breakdown checklist, and the self-reported percentage bars.
5. **Step 5 — Find a Job:** Go to **Jobs**, search for `"Python Developer"`.
6. **Step 6 — Skill Compatibility:** Click on the **Python Developer** job (TechCorp Solutions). Observe the transparent **Skill Compatibility Analysis**:
   - Compatibility: **66% Match**
   - Matched Skills: `✔ Python`, `✔ SQL`
   - Skills to Develop: `⚠ Flask`
   - *Strictly computed using Python logic — no AI black box!*
7. **Step 7 — Apply:** Click **Apply for this Job**, enter a cover note, and submit. Check **My Applications** to see status as `Applied`.
8. **Step 8 — Find Internship:** Open **Internships**, search for `"Python & Backend Development Intern"`, inspect requirements, and submit application.
9. **Step 9 — Turn Skills into Earnings:** Go to **Skill Marketplace** &rarr; **+ Offer Your Skill to Earn**. Create:
   - Title: *Record Writing & Document Formatting*
   - Skills: *Typing, MS Word, Record Writing*
   - Price: *₹500*
   - Delivery: *2 Days*
10. **Step 10 — Customer Discovers Service:** Log out, then 1-click login as **Customer (Prof. Sharma)**. Search `"Record Writing"` in the Marketplace. Inspect Arjun's provider card and price.
11. **Step 11 — Order Service:** Click **Request Service**, enter requirements (*"Please format 10 pages of Physics lab observation data and write clean record diagrams"*), and confirm order.
12. **Step 12 — Complete Service:** Switch to student **Arjun**, navigate to **Orders**. Accept the order (`Accepted`), mark it `In Progress`, and then click `Mark Completed`.
13. **Step 13 — Demo Earnings:** Navigate to **My Earnings**. View the prominent hero banner: **₹500 DEMO EARNINGS** with disclaimer and audit log.
14. **Step 14 — Customer Rating:** Switch to **Prof. Sharma**, view **Orders**, rate the completed order **⭐⭐⭐⭐⭐ 5 Stars** with a glowing review. Notice Arjun's rating automatically recalculates!
15. **Step 15 — Portfolio Showcase:** Open Arjun's public portfolio (`/profile/1`). View verified skills, customer review, listed services, student projects (*Smart Campus Assistant*), and achievements.
16. **Step 16 — Connect:** Open **Connect**, search for *Sneha Reddy* or *TechCorp Solutions*, and toggle the **🤝 Connect** button.
17. **Step 17 — Admin Oversight:** 1-click login as **Admin**. Open the **Admin Dashboard** to show judges the university telemetry: total users, active jobs, completed orders, demo earnings tally, user management table, and announcements publisher.

---

## 🚀 Installation & Running Locally

### 1. Prerequisites
- Python 3.10+ (Tested on Python 3.14)

### 2. Setup Virtual Environment (Optional but Recommended)
```bash
# Windows PowerShell / Command Prompt
python -m venv venv
venv\Scripts\activate

# macOS / Linux
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Initialize Database & Seed Demo Data
```bash
python database/seed_data.py
```
*(Creates `database.db` with 5 students, 3 employers, 8 jobs, 6 internships, 8 services, 8 opportunities, 5 projects, 5 achievements, and sample orders)*

### 5. Run the Automated Test Suite
```bash
python test_app.py
```
*(Runs 6 automated test cases verifying database counts, Python skill compatibility, auth, and the full 17-step demo story)*

### 6. Start the Application
```bash
python app.py
```

Open your web browser and navigate to:
**`http://127.0.0.1:5000`**

---

## 🏆 Ideathon Value Proposition

| Dimension | Traditional College Portals | MR EARN & CONNECT |
| :--- | :--- | :--- |
| **Scope** | Disjointed notice boards & job links | Unified ecosystem (Jobs, Internships, Services, Gigs, Portfolio) |
| **Skill Monetization** | Zero support for student micro-services | Working campus skill marketplace (₹500 record writing, typing, coding) |
| **Algorithm Transparency** | Opaque black-box AI matchers or no matching | **100% Explainable Python Skill Compatibility** (Matched ✔ vs Missing ⚠) |
| **Portfolio Utility** | Stale static PDF resumes | Live web portfolio with ratings, projects, achievements, and order history |
| **Campus Identity** | Generic commercial software | Custom branded for **Malla Reddy Deemed to be University, Tirupati** |

---

## 🔮 Future Roadmap

- [ ] Mobile App for iOS & Android
- [ ] College Placement ERP Integration
- [ ] Blockchain Skill Verification Certificates
- [ ] Live Production Payment Gateway (UPI / QR / Razorpay)
- [ ] Multilingual Support (Telugu, Hindi, English)
- [ ] Tier-1 Tech Company Integration MOUs
- [ ] Departmental Outcome-Based NBA Accreditation Analytics

---

## 📜 License

Created for educational and innovation demonstration at **Malla Reddy Deemed to be University (MRDU), Tirupati**.

*“Every student has skills. Every skill can create an opportunity.”*
