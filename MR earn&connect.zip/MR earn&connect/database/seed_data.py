import os
import sys
from werkzeug.security import generate_password_hash

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database.db import get_db_connection, init_db

def seed_database():
    """Wipes and seeds the SQLite database with rich demo data for MR EARN & CONNECT."""
    init_db()
    conn = get_db_connection()
    cur = conn.cursor()

    # Clear existing data
    tables = [
        'connections', 'announcements', 'projects', 'achievements', 'opportunities',
        'earnings', 'ratings', 'orders', 'services', 'applications', 'internships',
        'jobs', 'companies', 'skills', 'student_profiles', 'users'
    ]
    for table in tables:
        cur.execute(f"DELETE FROM {table};")
        cur.execute(f"DELETE FROM sqlite_sequence WHERE name='{table}';")

    default_pw = generate_password_hash("Student@123")
    employer_pw = generate_password_hash("Employer@123")
    customer_pw = generate_password_hash("Customer@123")
    admin_pw = generate_password_hash("Admin@123")

    # 1. USERS
    users = [
        # Students (1-5)
        ("Arjun Kumar", "arjun@student.mrdu.edu", default_pw, "student", "+91 9876543210", "student_arjun.png"),
        ("Sneha Reddy", "sneha@student.mrdu.edu", default_pw, "student", "+91 9876543211", "student_sneha.png"),
        ("Rahul Sharma", "rahul@student.mrdu.edu", default_pw, "student", "+91 9876543212", "student_rahul.png"),
        ("Ananya Verma", "ananya@student.mrdu.edu", default_pw, "student", "+91 9876543213", "student_ananya.png"),
        ("Sai Teja", "saiteja@student.mrdu.edu", default_pw, "student", "+91 9876543214", "student_saiteja.png"),
        
        # Employers (6-8)
        ("TechCorp Solutions HR", "techcorp@company.com", employer_pw, "employer", "+91 8001234567", "company_techcorp.png"),
        ("NexaAI Labs Talent", "nexaai@company.com", employer_pw, "employer", "+91 8002345678", "company_nexaai.png"),
        ("DataPulse Systems Recruiter", "datapulse@company.com", employer_pw, "employer", "+91 8003456789", "company_datapulse.png"),
        
        # Customer (9)
        ("Prof. K. Sharma", "sharma@faculty.mrdu.edu", customer_pw, "customer", "+91 9123456780", "faculty_sharma.png"),
        
        # Admin (10)
        ("MRDU Platform Admin", "admin@mrearn.mrdu.edu", admin_pw, "admin", "+91 9998887770", "admin_avatar.png"),
    ]

    for u in users:
        cur.execute(
            "INSERT INTO users (name, email, password, role, phone, avatar) VALUES (?, ?, ?, ?, ?, ?)",
            u
        )

    # 2. STUDENT PROFILES (Users 1-5)
    profiles = [
        (1, "student_arjun.png", "Malla Reddy Deemed to be University, Tirupati", "Computer Science & Engineering", "B.Tech CSE-AIML", "1st Year", "12th Science (94%), B.Tech Pursuing", 9.1, "Passionate first-year CSE-AIML student eager to build real-world software, apply Python and web skills, and help fellow students with academic record formatting.", "https://drive.google.com/sample_resume_arjun", "Full-time / Internship", "Tirupati / Hybrid / Remote"),
        (2, "student_sneha.png", "Malla Reddy Deemed to be University, Tirupati", "Data Science & AI", "B.Tech CSE-DS", "2nd Year", "12th Science (96%), B.Tech Pursuing", 9.4, "Second-year Data Science student passionate about machine learning, presentation design, and statistical data visualization.", "https://drive.google.com/sample_resume_sneha", "Internship", "Bengaluru / Hyderabad / Remote"),
        (3, "student_rahul.png", "Malla Reddy Deemed to be University, Tirupati", "Electronics & Communication", "B.Tech ECE", "3rd Year", "12th Science (89%), B.Tech Pursuing", 8.6, "Third-year ECE student with strong C/Java foundations, automation scripts, and peer tutoring experience.", "https://drive.google.com/sample_resume_rahul", "Full-time", "Chennai / Hyderabad"),
        (4, "student_ananya.png", "Malla Reddy Deemed to be University, Tirupati", "Cyber Security & IoT", "B.Tech CSE-Cyber", "2nd Year", "12th Science (91%), B.Tech Pursuing", 8.9, "UI/UX enthusiast and frontend developer creating responsive web designs, digital illustrations, and cybersecurity labs.", "https://drive.google.com/sample_resume_ananya", "Internship / Freelance", "Remote / Hybrid"),
        (5, "student_saiteja.png", "Malla Reddy Deemed to be University, Tirupati", "Mechanical & Mechatronics", "B.Tech Mech", "4th Year", "12th Science (85%), B.Tech Pursuing", 8.2, "Final-year student specializing in robotics control scripts in Python, lab documentation, and student event coordination.", "https://drive.google.com/sample_resume_saiteja", "Full-time", "Tirupati / Bengaluru"),
    ]

    for p in profiles:
        cur.execute(
            """INSERT INTO student_profiles 
               (user_id, photo, college, department, course, year, education, cgpa, bio, resume, preferred_job_type, preferred_location)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            p
        )

    # 3. SKILLS FOR STUDENTS
    # Arjun: Python (Advanced), HTML (Intermediate), SQL (Intermediate), Typing (Advanced), Record Writing (Advanced)
    # This precisely matches step 3 of the Ideathon Demo Flow!
    skills_data = [
        # Arjun (ID 1)
        (1, "Python", "Technical", "Advanced"),
        (1, "HTML", "Technical", "Intermediate"),
        (1, "SQL", "Technical", "Intermediate"),
        (1, "Typing", "Digital", "Advanced"),
        (1, "Record Writing", "Digital", "Advanced"),
        (1, "Communication", "Soft", "Intermediate"),
        
        # Sneha (ID 2)
        (2, "Python", "Technical", "Advanced"),
        (2, "Machine Learning", "Technical", "Intermediate"),
        (2, "PowerPoint", "Digital", "Advanced"),
        (2, "Graphic Design", "Digital", "Intermediate"),
        (2, "Presentation", "Soft", "Advanced"),
        (2, "Teamwork", "Soft", "Advanced"),

        # Rahul (ID 3)
        (3, "C", "Technical", "Advanced"),
        (3, "Java", "Technical", "Intermediate"),
        (3, "Document Formatting", "Digital", "Advanced"),
        (3, "Data Entry", "Digital", "Intermediate"),
        (3, "Problem Solving", "Soft", "Advanced"),

        # Ananya (ID 4)
        (4, "HTML", "Technical", "Advanced"),
        (4, "CSS", "Technical", "Advanced"),
        (4, "JavaScript", "Technical", "Intermediate"),
        (4, "Graphic Design", "Digital", "Advanced"),
        (4, "Time Management", "Soft", "Advanced"),

        # Sai Teja (ID 5)
        (5, "Python", "Technical", "Intermediate"),
        (5, "MS Word", "Digital", "Advanced"),
        (5, "Notes Preparation", "Digital", "Advanced"),
        (5, "Leadership", "Soft", "Advanced"),
    ]

    for s in skills_data:
        cur.execute("INSERT INTO skills (student_id, name, category, level) VALUES (?, ?, ?, ?)", s)

    # 4. COMPANIES (Users 6-8)
    companies_data = [
        (6, "TechCorp Solutions", "Leading enterprise software and cloud consultancy offering internships and graduate software engineering roles.", "Tirupati Tech Park, AP", "https://techcorp.example.com", "company_techcorp.png"),
        (7, "NexaAI Labs", "Fast-growing generative AI and deep tech startup building intelligent automation platforms.", "Bengaluru / Hybrid", "https://nexaai.example.com", "company_nexaai.png"),
        (8, "DataPulse Systems", "Analytics and big data solutions provider empowering organizations with modern data stacks.", "Hyderabad, Telangana", "https://datapulse.example.com", "company_datapulse.png"),
    ]

    for c in companies_data:
        cur.execute("INSERT INTO companies (user_id, company_name, description, location, website, logo) VALUES (?, ?, ?, ?, ?, ?)", c)

    # 5. JOBS (8 Jobs)
    # Company 1: TechCorp (ID 1)
    # Company 2: NexaAI (ID 2)
    # Company 3: DataPulse (ID 3)
    jobs_data = [
        (1, "Python Developer", "Software & IT", 
         "Develop scalable backend APIs and database integrations using Python and SQL. Ideal for proactive students and fresh graduates.",
         "Build and maintain REST APIs; Write optimized SQL queries; Coordinate with frontend teammates; Write clean unit tests.",
         "B.Tech CSE/IT/AIML (Graduating 2026/2027) with min 7.5 CGPA",
         "Python, SQL, Flask",
         "Tirupati, AP", "Full-time", "₹4.5 - ₹6.5 LPA"),
         
        (2, "Frontend Web Developer", "Software & IT",
         "Craft intuitive, high-performance web user interfaces for our AI-powered SaaS product suite.",
         "Translate Figma mockups into pixel-perfect responsive HTML/CSS; Implement dynamic UI interactions in JavaScript.",
         "B.Tech CSE/IT/ECE with portfolio of web projects",
         "HTML, CSS, JavaScript, Responsive Design",
         "Bengaluru / Hybrid", "Full-time", "₹5.0 - ₹8.0 LPA"),

        (3, "Junior Data Analyst", "Data & Analytics",
         "Analyze operational datasets, generate weekly business intelligence reports, and build automated SQL pipelines.",
         "Query relational databases; Prepare data visual summaries; Document schema metrics.",
         "B.Tech in CSE, Data Science, or Mathematics",
         "Python, SQL, Excel, Data Entry",
         "Hyderabad, Telangana", "Full-time", "₹4.2 - ₹6.0 LPA"),

        (1, "QA & Software Test Associate", "Software & IT",
         "Test web applications, document edge cases, conduct manual exploratory testing, and write basic automated test scripts.",
         "Execute test suites; Report bugs in issue trackers; Verify bug fixes with developers.",
         "B.Tech any branch with analytical thinking",
         "Python, Java, Problem Solving, Communication",
         "Tirupati Tech Park, AP", "Full-time", "₹3.8 - ₹5.0 LPA"),

        (2, "Backend API Engineer", "Software & IT",
         "Architect reliable web microservices and integrate database schemas with real-time web hooks.",
         "Design RESTful endpoints; Optimize query execution plans; Maintain cloud service logging.",
         "B.Tech CSE/AIML with solid backend knowledge",
         "Python, Flask, SQL, Linux",
         "Hyderabad, Telangana", "Full-time", "₹6.0 - ₹9.0 LPA"),

        (3, "Technical Documentation Specialist", "Content & Documentation",
         "Create developer documentation, user manuals, release notes, and structured knowledge base articles.",
         "Format technical specifications; Collaborate with engineers; Maintain document templates in MS Word.",
         "Any graduate with excellent English writing and formatting skills",
         "Typing, Document Formatting, MS Word, Communication",
         "Remote", "Part-time", "₹3.0 - ₹4.2 LPA"),

        (1, "Cloud Operations Trainee", "Cloud & DevOps",
         "Assist our infrastructure engineering team in monitoring Linux servers, automation scripts, and network health.",
         "Monitor uptime alerts; Write shell/Python cron automation scripts; Maintain server backup logs.",
         "B.Tech CSE/ECE with basic operating system concepts",
         "Python, Linux, Networking, Teamwork",
         "Tirupati, AP", "Full-time", "₹4.0 - ₹5.5 LPA"),

        (2, "Associate Full-Stack Developer", "Software & IT",
         "Collaborate across both frontend and backend layers to deliver end-to-end features for educational web apps.",
         "Implement database tables; Expose REST endpoints; Build mobile-friendly frontend pages.",
         "B.Tech CSE/IT with strong fundamentals",
         "Python, JavaScript, HTML, CSS, SQL",
         "Bengaluru / Remote", "Full-time", "₹5.5 - ₹7.5 LPA"),
    ]

    for j in jobs_data:
        cur.execute("""INSERT INTO jobs 
            (company_id, title, category, description, responsibilities, qualification, skills, location, job_type, salary)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""", j)

    # 6. INTERNSHIPS (6 Internships)
    internships_data = [
        (1, "Python & Backend Development Intern",
         "Work directly under senior engineers building student-facing web modules. Hands-on mentorship with real production codebase.",
         "Python, SQL, Git", "B.Tech 1st to 3rd Year (CSE/AIML)", "3 Months", "₹12,000 / Month", "Tirupati / Hybrid", "30 Mar 2026"),

        (2, "Web Design & UI Development Intern",
         "Design dynamic web components, landing pages, and interactive student portals.",
         "HTML, CSS, JavaScript", "Students with responsive web design passion", "2 Months", "₹10,000 / Month", "Remote", "15 Apr 2026"),

        (3, "AI/ML Research & Data Intern",
         "Assist research engineers in data preprocessing, pipeline creation, and evaluating machine learning benchmarks.",
         "Python, Machine Learning, Problem Solving", "B.Tech CSE-AIML or Data Science students", "6 Months", "₹15,000 / Month", "Bengaluru / Hybrid", "20 Apr 2026"),

        (1, "Data Management & Analytics Intern",
         "Clean, validate, and summarize institutional and product data tables.",
         "Data Entry, SQL, Excel, Document Formatting", "All engineering disciplines eligible", "2 Months", "₹8,000 / Month", "Tirupati, AP", "10 Apr 2026"),

        (2, "Technical Documentation & Notes Intern",
         "Structure lab manuals, coding problem sets, and academic study guides.",
         "Typing, Document Formatting, MS Word, Presentation", "Undergraduate students with typing proficiency", "1 Month", "₹6,000 / Month", "Remote", "05 May 2026"),

        (3, "Cyber Security Trainee Intern",
         "Perform vulnerability assessments on web applications and document compliance reports.",
         "Python, Networking, Linux, Problem Solving", "2nd/3rd Year CSE-Cyber Security students", "3 Months", "₹11,000 / Month", "Tirupati Tech Park", "25 Apr 2026"),
    ]

    for it in internships_data:
        cur.execute("""INSERT INTO internships 
            (company_id, title, description, skills, eligibility, duration, stipend, location, deadline)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""", it)

    # 7. SERVICES (8 Marketplace Services)
    services_data = [
        (1, "Record Writing & Document Formatting", "Academic & Writing",
         "Neat, accurate lab record writing, assignment drafting, and academic document formatting adhering to university guidelines.",
         "Typing, MS Word, Document Formatting, Record Writing", 500.0, "2 Days", "Available"),

        (2, "Handwritten Assignment & Notes Preparation", "Academic & Writing",
         "Crystal-clear cursive and print handwriting for lecture notes, laboratory observation copies, and summary charts.",
         "Handwriting, Notes Preparation, Document Formatting", 350.0, "1 Day", "Available"),

        (3, "Professional PPT & Presentation Design", "Design & Media",
         "High-impact PowerPoint presentations with custom graphics, slide animations, and structured content for seminars and project reviews.",
         "PowerPoint, Graphic Design, Presentation", 600.0, "2 Days", "Available"),

        (4, "Fast Typing & Data Entry in Excel", "Data & Office",
         "Accurate typing at 55+ WPM. Tabulation of survey responses, lab readings, and structured data entry into clean Excel sheets.",
         "Typing, Data Entry, MS Word", 400.0, "1 Day", "Available"),

        (5, "Responsive Portfolio Website Creation", "Software & Web",
         "Custom-designed personal portfolio or project showcase website built with clean HTML5, CSS3, and JavaScript.",
         "HTML, CSS, JavaScript, Basic Website Creation", 1500.0, "3 Days", "Available"),

        (6, "Python Scripting & Automation Helper", "Software & Web",
         "Quick Python scripts for file renaming, PDF extraction, web scraping, and automated data processing tasks.",
         "Python, SQL, Problem Solving", 800.0, "2 Days", "Available"),

        (7, "Event Posters & Social Media Graphic Design", "Design & Media",
         "Vibrant event posters, social media banners, and brochure layouts for college clubs, fests, and student startups.",
         "Graphic Design, Presentation, Document Formatting", 450.0, "1 Day", "Available"),

        (8, "C & Python Programming Peer Tutoring", "Tutoring & Mentorship",
         "1-on-1 coding mentorship covering basic algorithms, pointers, OOP in Python, and lab exam problem-solving.",
         "Python, C, Problem Solving, Communication", 500.0, "1 Day", "Available"),
    ]

    for srv in services_data:
        cur.execute("""INSERT INTO services 
            (provider_id, title, category, description, skills, price, delivery_time, availability)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)""", srv)

    # 8. OPPORTUNITIES (8 Items)
    opps_data = [
        ("MRDU Campus Ideathon 2026", "Ideathon", "Malla Reddy Deemed to be University, Tirupati",
         "Annual flagship innovation competition encouraging student teams to present scalable solutions for smart campuses, sustainability, and rural fintech. Cash prizes worth ₹1,00,000!",
         "15 April 2026", "MRDU Tirupati Auditorium", "05 April 2026", "https://mrdu.ac.in/ideathon2026"),

        ("Smart India Hackathon Regional Qualifiers", "Hackathon", "Ministry of Education & AICTE",
         "National-level hackathon tackling problem statements given by central ministries and premier industries. Mentorship and incubation support provided.",
         "22 May 2026", "Hybrid / Nodal Centers", "30 April 2026", "https://sih.gov.in"),

        ("AWS Cloud Practitioner Student Scholarship", "Scholarship", "Amazon Web Services Education",
         "100% exam voucher and free cloud sandbox training for meritorious B.Tech undergraduates.",
         "10 May 2026", "Online Examination", "25 April 2026", "https://aws.amazon.com/education/students"),

        ("Tirupati Student Innovators Bootcamp", "Workshop", "MRDU Innovation & Incubation Cell",
         "Three-day hands-on workshop on product design, rapid MVP prototyping with Python/Flask, and venture pitching.",
         "18 April 2026", "MRDU Innovation Center, Tirupati", "12 April 2026", "https://mrdu.ac.in/bootcamp"),

        ("National Youth Coding Championship 2026", "Competition", "Tech Guild India",
         "Competitive programming contest testing data structures, algorithms, and logical problem solving.",
         "02 May 2026", "Online Portal", "28 April 2026", "https://techguild.org/nycc2026"),

        ("Google Developer Student Clubs Solution Challenge", "Hackathon", "Google Developers",
         "Global contest for university students to build solutions for one or more of the UN Sustainable Development Goals using Google tech.",
         "15 May 2026", "Virtual Summit", "01 May 2026", "https://developers.google.com/community/gdsc"),

        ("Microsoft Learn AI Skills Initiative", "Certification", "Microsoft Learn & NASSCOM",
         "Free certification pathway on foundational artificial intelligence, machine learning ethics, and cloud concepts.",
         "Rolling Basis", "Self-paced Online", "31 May 2026", "https://learn.microsoft.com/ai-skills"),

        ("Andhra Pradesh University Startup Pitch Fest", "Career Event", "AP Innovation Society",
         "Opportunity for student entrepreneurs to pitch working prototypes directly to seed angel investors and startup mentors.",
         "28 May 2026", "SVU Convention Hall, Tirupati", "15 May 2026", "https://apis.ap.gov.in/pitchfest"),
    ]

    for op in opps_data:
        cur.execute("""INSERT INTO opportunities 
            (title, category, organization, description, date, location, deadline, link)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)""", op)

    # 9. STUDENT PROJECTS (5 Projects)
    projects_data = [
        (1, "Smart Campus Assistant",
         "A unified chatbot and event notification assistant for MRDU students to query exam timetables, bus timings, and campus services.",
         "Python, Flask, SQLite, HTML, CSS", "Arjun Kumar, Rahul Sharma", "Web & Software", "Completed",
         "https://github.com/mrdu-students/smart-campus-assistant", "proj_campus_assistant.png"),

        (2, "Automated QR Attendance Scanner",
         "Real-time classroom attendance tracker utilizing dynamic QR codes and SQLite backends with export to Excel.",
         "Python, OpenCV, Flask, SQLite", "Sneha Reddy, Arjun Kumar", "AI & Automation", "Completed",
         "https://github.com/mrdu-students/qr-attendance", "proj_qr_scanner.png"),

        (3, "Campus Book & Record Exchange",
         "Peer-to-peer marketplace allowing senior students to pass down textbooks, lab records, and calculator sets to juniors.",
         "HTML, CSS, JavaScript, SQLite, Python", "Rahul Sharma", "Web & Software", "Completed",
         "https://github.com/mrdu-students/book-exchange", "proj_book_exchange.png"),

        (4, "Student Budget & Expense Tracker",
         "Lightweight financial management app designed specifically for hostel students to budget mess, travel, and project expenses.",
         "Python, Tkinter, SQLite", "Ananya Verma", "Desktop Software", "Completed",
         "https://github.com/mrdu-students/student-budget", "proj_budget_tracker.png"),

        (5, "Smart Hostel Gatepass Portal",
         "Digital gatepass application and parent approval dashboard with SMS notification simulation.",
         "Flask, Jinja2, SQLite, HTML5, CSS3", "Sai Teja", "Web Application", "Completed",
         "https://github.com/mrdu-students/hostel-gatepass", "proj_gatepass.png"),
    ]

    for pj in projects_data:
        cur.execute("""INSERT INTO projects 
            (student_id, title, description, technologies, team_members, category, status, project_link, image)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""", pj)

    # 10. ACHIEVEMENTS (5 Items)
    achievements_data = [
        (1, "First Prize - MRDU Intra-College Ideathon 2025", "Ideathon", "MRDU Tirupati",
         "Awarded 1st place among 45 student teams for proposing 'MR EARN & CONNECT' student skill-monetization framework.", "Nov 2025", "https://mrdu.ac.in/certificates/arjun_ideathon"),

        (2, "NPTEL Elite + Gold in Python for Data Science", "Certificate", "IIT Madras / NPTEL",
         "Secured 92% in 12-week national certification course with top 2% candidate percentile.", "Oct 2025", "https://nptel.ac.in/noc/Ecertificate/?q=sneha_python"),

        (3, "Runner-up - Tirupati Regional Inter-College Hackathon", "Hackathon", "SV University / IEEE Student Branch",
         "Built a decentralized blood donation alert tracker within 24 hours.", "Jan 2026", "https://ieee-tirupati.org/awards/rahul"),

        (4, "Certified Front-End Web Developer", "Certificate", "Coursera / Meta Front-End Specialization",
         "Completed rigorous 9-course specialization in responsive design, CSS architecture, and JS fundamentals.", "Dec 2025", "https://coursera.org/verify/ananya_meta_fe"),

        (5, "Best Student Innovator Award - MRDU Tech Fest", "Award", "Malla Reddy University",
         "Honored for designing low-cost smart irrigation model for university horticulture garden.", "Feb 2026", "https://mrdu.ac.in/awards/saiteja"),
    ]

    for ac in achievements_data:
        cur.execute("""INSERT INTO achievements 
            (student_id, title, category, organization, description, date, proof_link)
            VALUES (?, ?, ?, ?, ?, ?, ?)""", ac)

    # 11. ANNOUNCEMENTS (4 Items)
    announcements_data = [
        ("MRDU Campus Ideathon 2026 Registration Open!",
         "Students across all departments are invited to submit 2-page project proposals for the upcoming MRDU Campus Ideathon 2026. Attractive cash prizes and incubation slots await winning teams!",
         "Ideathon", "01 March 2026"),

        ("Campus Recruitment Drive - TechCorp & DataPulse",
         "TechCorp Solutions and DataPulse Systems will be hosting on-campus technical interviews for 2026 graduating batches and 2027 internship cohorts. Update your MR EARN & CONNECT profiles.",
         "Placement", "28 February 2026"),

        ("Hands-on Workshop on Python & Web APIs",
         "Department of CSE-AIML is conducting a weekend hands-on workshop on building web applications using Python, Flask, and SQLite at Lab Block 3.",
         "Workshop", "25 February 2026"),

        ("Notice: Academic Record & Lab Submission Guidelines",
         "All laboratory observation registers and record books must be formatted according to the revised 2026 department guidelines before end-semester exams.",
         "Notice", "20 February 2026"),
    ]

    for an in announcements_data:
        cur.execute("INSERT INTO announcements (title, content, category, date) VALUES (?, ?, ?, ?)", an)

    # 12. SAMPLE ORDERS, EARNINGS & RATINGS
    # Order 1: Sneha completed service 3 (PPT Design) for Prof. Sharma -> ₹600 earned and rated 5 stars!
    cur.execute("""INSERT INTO orders 
        (service_id, customer_id, provider_id, requirements, status, amount, created_at, completed_at)
        VALUES (3, 9, 2, 'Prepare 20-slide technical presentation for National AI Seminar on Healthcare with clean charts.', 'Completed', 600.0, '2026-02-15 10:00:00', '2026-02-17 16:30:00')""")
    order_id_1 = cur.lastrowid

    cur.execute("""INSERT INTO earnings (provider_id, order_id, amount, date)
        VALUES (2, ?, 600.0, '2026-02-17 16:30:00')""", (order_id_1,))

    cur.execute("""INSERT INTO ratings (order_id, customer_id, provider_id, service_id, rating, review, created_at)
        VALUES (?, 9, 2, 3, 5, 'Exceptional slide deck! Clean typography, elegant visuals, and delivered well before the seminar deadline. Highly recommended.', '2026-02-18 09:00:00')""", (order_id_1,))

    # Order 2: Rahul completed service 6 (Python Automation) for Prof. Sharma -> ₹800 earned, 5 stars!
    cur.execute("""INSERT INTO orders 
        (service_id, customer_id, provider_id, requirements, status, amount, created_at, completed_at)
        VALUES (6, 9, 3, 'Create Python script to merge 50 student PDF certificates and rename by roll number.', 'Completed', 800.0, '2026-02-20 14:00:00', '2026-02-21 18:00:00')""")
    order_id_2 = cur.lastrowid

    cur.execute("""INSERT INTO earnings (provider_id, order_id, amount, date)
        VALUES (3, ?, 800.0, '2026-02-21 18:00:00')""", (order_id_2,))

    cur.execute("""INSERT INTO ratings (order_id, customer_id, provider_id, service_id, rating, review, created_at)
        VALUES (?, 9, 3, 6, 5, 'The Python script saved our department over 6 hours of manual file sorting. Worked like a charm!', '2026-02-22 11:15:00')""", (order_id_2,))

    # 13. SAMPLE APPLICATIONS
    # Sneha applied to NexaAI Frontend
    cur.execute("""INSERT INTO applications (user_id, job_id, internship_id, status, cover_note, applied_at)
        VALUES (2, 2, NULL, 'Shortlisted', 'Strong background in data visualization and responsive UI design.', '2026-02-24 11:30:00')""")
    
    # Rahul applied to TechCorp Cloud Trainee
    cur.execute("""INSERT INTO applications (user_id, job_id, internship_id, status, cover_note, applied_at)
        VALUES (3, 7, NULL, 'Under Review', 'Experience with Linux systems and Python automation scripts.', '2026-02-25 15:45:00')""")

    # 14. CONNECTIONS
    connections_data = [
        (1, 2, "Connected"),
        (1, 3, "Connected"),
        (1, 6, "Connected"), # Arjun connected with TechCorp
        (2, 4, "Connected"),
        (3, 5, "Connected"),
    ]
    for c in connections_data:
        cur.execute("INSERT INTO connections (sender_id, receiver_id, status) VALUES (?, ?, ?)", c)

    conn.commit()
    conn.close()
    print("Database seeded successfully with comprehensive demo data for MR EARN & CONNECT!")

if __name__ == "__main__":
    seed_database()
